/* Progressive enhancement: the journal remains readable without JavaScript. */
(() => {
  const cards = [...document.querySelectorAll('[data-story]')];
  const filters = [...document.querySelectorAll('[data-filter]')];
  const search = document.querySelector('#story-search');
  const status = document.querySelector('#result-status');
  const empty = document.querySelector('#empty-state');
  const categories = ['all', 'coast', 'mountains', 'woodland', 'desert'];
  let category = 'all';
  function update() {
    const query = (search?.value || '').trim().toLowerCase();
    let count = 0;
    cards.forEach(card => {
      const visible = (category === 'all' || card.dataset.category === category) && card.dataset.search.includes(query);
      card.hidden = !visible;
      if (visible) count++;
    });
    filters.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.filter === category)));
    if (status) status.textContent = `${count} ${count === 1 ? 'story' : 'stories'}${category === 'all' ? ' to explore' : ` in ${category}`}${query ? ` matching “${search.value.trim()}”` : ''}`;
    if (empty) empty.hidden = count !== 0;
  }
  if (cards.length && search) {
    document.querySelector('.journal-tools').hidden = false;
    status.hidden = false;
    const initial = new URLSearchParams(location.search).get('category');
    if (categories.includes(initial)) category = initial;
    filters.forEach(button => button.addEventListener('click', () => {
      category = button.dataset.filter;
      const url = new URL(location.href);
      if (category === 'all') url.searchParams.delete('category'); else url.searchParams.set('category', category);
      history.replaceState(null, '', url.pathname + url.search + url.hash);
      update();
    }));
    search.addEventListener('input', update);
    addEventListener('popstate', () => {
      const value = new URLSearchParams(location.search).get('category');
      category = categories.includes(value) ? value : 'all';
      update();
    });
    update();
  }
  const top = document.querySelector('.scroll-top');
  if (top) {
    const showTop = () => { top.hidden = scrollY < 650; };
    addEventListener('scroll', showTop, { passive: true });
    top.addEventListener('click', () => window.scrollTo({ top: 0, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' }));
    showTop();
  }
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') document.querySelector('.mobile-nav')?.removeAttribute('open');
  });
  document.addEventListener('click', event => {
    const menu = document.querySelector('.mobile-nav[open]');
    if (menu && !menu.contains(event.target)) menu.removeAttribute('open');
  });
})();
